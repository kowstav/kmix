"""Validate a pulled kernel before reusing an existing private CPU reference."""
from pathlib import Path
import hashlib
import json


def normalized_source(raw):
    # Kaggle may change transport line endings. No other text is discarded.
    return raw.decode("utf-8").replace("\r\n", "\n").encode("utf-8")


def validate_existing_kernel(folder, expected_metadata, expected_source):
    folder = Path(folder)
    actual = json.loads((folder / "kernel-metadata.json").read_text(encoding="utf-8"))
    for key in ["id", "language", "kernel_type"]:
        if actual.get(key) != expected_metadata[key]:
            raise ValueError("existing kernel differs: " + key)
    for key, value in {"is_private": True, "enable_gpu": False,
                       "enable_tpu": False, "enable_internet": False}.items():
        if actual.get(key) is not value:
            raise ValueError("existing kernel has unverified privacy/resource setting: " + key)
    for key in ["dataset_sources", "competition_sources", "kernel_sources"]:
        if sorted(actual.get(key, [])) != sorted(expected_metadata[key]):
            raise ValueError("existing kernel has different inputs: " + key)
    code = (folder / actual["code_file"]).resolve()
    if not code.is_relative_to(folder.resolve()):
        raise ValueError("existing code path escapes verification directory")
    raw = code.read_bytes()
    if normalized_source(raw) != normalized_source(expected_source):
        raise ValueError("existing kernel source differs; preserve and choose a new versioned ref")
    return {"physical_source_sha256": hashlib.sha256(raw).hexdigest(),
            "normalized_source_sha256": hashlib.sha256(normalized_source(raw)).hexdigest(),
            "comparison": "exact UTF-8 source allowing only CRLF/LF transport normalization",
            "metadata_checked": True}
