// TransformerOpt implementation. Wiring order matches SPEC section 3.3 and
// the arena stream order of arena_build.cpp exactly.
//
// Profiling (-DFX2_PROF): raw rdtsc (no lfence/rdtscp — the ~67-cycle
// serialized stamp would distort short sections; raw back-to-back stamps
// measure ~10-20 core cycles) section accumulators, one per call site,
// aggregated into the four SPEC section-9 groups at print time and
// overhead-corrected by the measured empty-section delta.

#include "model_opt.h"

#include <immintrin.h>

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <vector>

#include "arena_build.h"
#include "attn.h"
#include "glue.h"
#include "kda.h"
#include "kda_math.h"
#include "qmat_dense.h"
#include "qmat_sparse.h"
#if TF_AVX512
#include "qmat_avx512.h"   // AVX-512 VNNI twins of the matmul kernels (runtime dispatch on M.avx512, see below)
#endif

// Debug-only component isolation for the naive-vs-opt cross-check (never
// defined in the production build targets): swap the fused KDA step and/or
// the attention kernel for the naive path (bit-exact vs src/model.cpp) to
// attribute divergence per component.
#if defined(FX2_XCHECK_NAIVE_KDA) || defined(FX2_XCHECK_NAIVE_ATTN)
#include "../kernels.h"
#endif

namespace fx2 {
namespace opt {

namespace {
constexpr int V = 205, D = 192, NL = arch::NL, DH = 64, NH = 3, DMLP = arch::DMLP, NSKIP = arch::NSKIP;  // tf_arch.h
constexpr int ROPE_LEN = 131072;
// vanilla layer vi's attention window (attn_window.h: ATTN_WIN x its -DATTN_WIN_MULTS entry); the KV blobs, ring slots and
// var/fixed kernels are handled per layer by attn_layer_* (attn.h)
[[maybe_unused]] constexpr int WMAX = attn_win::WMAX;  // naive xcheck rings (FX2_XCHECK_NAIVE_ATTN)
// density thresholds for the sparse column kernels (qmat.h)
constexpr int DOWN_DENSE_NNZ =
    static_cast<int>(QMAT_SPARSE_DENSITY_THRESHOLD * DMLP);  // 729
constexpr int PRIOR_DENSE_NNZ =
    static_cast<int>(QMAT_SPARSE_DENSITY_THRESHOLD * V);  // 194

// beta projection: 3x192 fp32 matvec on xn. Bit-identical to the naive
// fx2::dot_f32(xn, w, 192) (same 8-wide fmadd chain + hsum tree).
inline float dot192(const float* a, const float* b) {
  __m256 acc = _mm256_setzero_ps();
  for (int i = 0; i < 192; i += 8)
    acc = _mm256_fmadd_ps(_mm256_loadu_ps(a + i), _mm256_loadu_ps(b + i), acc);
  return hsum256v(acc);
}
}  // namespace

// ---------------------------------------------------------------------------
// profiling sites
// ---------------------------------------------------------------------------
namespace {

enum PSite : int {
  // group 0: int4 x int8 matmuls (ALL arenas)
  PS_MM_PRIOR = 0,
  PS_MM_KQKV,
  PS_MM_GUP,
  PS_MM_GDN,
  PS_MM_KOP,
  PS_MM_VQKV,
  PS_MM_VOP,
  PS_MM_MLP_UP,
  PS_MM_MLP_DOWN,
  PS_MM_UNEMB,
  // group 1: vanilla attention mechanism
  PS_AT_INSERT,
  PS_AT_STEP,
  // group 2: kimi linear attention mechanism
  PS_KD_BETA,
  PS_KD_STEP,
  // group 3: everything else
  PS_EL_PRIORQ,
  PS_EL_EMBED,
  PS_EL_RESID,
  PS_EL_NQ_KIMI,
  PS_EL_NQ_VAN,
  PS_EL_NQ_MLP,
  PS_EL_NQ_FIN,
  PS_EL_HEADPREP,
  PS_EL_OQ,
  PS_EL_HEAD,
  PS_N
};

#ifdef FX2_PROF
struct PSiteInfo {
  const char* name;
  int group;
};
const PSiteInfo kPSites[PS_N] = {
    {"prior spmv (int4 cols)", 0},
    {"kimi q/k/v proj (27)", 0},
    {"gate up (fg+og, 18)", 0},
    {"gate down (fg+og, 18)", 0},
    {"kimi out proj (9)", 0},
    {"van q/k/v proj (9)", 0},
    {"van out proj (3)", 0},
    {"mlp up + relu2q (12)", 0},
    {"mlp down spmv (12)", 0},
    {"unembed (1)", 0},
    {"kv insert (3)", 1},
    {"attn step qk+sm+pv (3)", 1},
    {"beta matvec (9)", 2},
    {"kda fused step (9)", 2},
    {"prior quant+idx", 3},
    {"embed combine", 3},
    {"resid/skip/tok ops", 3},
    {"norm+quant kimi (9)", 3},
    {"norm+quant van (3)", 3},
    {"norm+quant mlp (12)", 3},
    {"final norm+quant", 3},
    {"head-prep norm/rope/q (3)", 3},
    {"attnout quant (12)", 3},
    {"softcap+softmax head", 3},
};
const char* kGroups[4] = {"int4xint8 matmuls", "vanilla attention mechanism",
                          "kimi (KDA) mechanism", "everything else"};

inline uint64_t prof_rdtsc() {
  unsigned lo, hi;
  asm volatile("rdtsc" : "=a"(lo), "=d"(hi)::"memory");
  return (static_cast<uint64_t>(hi) << 32) | lo;
}
uint64_t g_pacc[PS_N] = {};
uint64_t g_pcalls[PS_N] = {};
struct PScope {
  int s;
  uint64_t t0;
  explicit PScope(int s_) : s(s_), t0(prof_rdtsc()) {}
  ~PScope() {
    g_pacc[s] += prof_rdtsc() - t0;
    g_pcalls[s]++;
  }
};
#define PSCOPE(site) PScope pscope_(site)
#else
#define PSCOPE(site) \
  do {               \
  } while (0)
#endif

}  // namespace

void prof_reset() {
#ifdef FX2_PROF
  std::memset(g_pacc, 0, sizeof(g_pacc));
  std::memset(g_pcalls, 0, sizeof(g_pcalls));
#endif
}

bool prof_enabled() {
#ifdef FX2_PROF
  return true;
#else
  return false;
#endif
}

void prof_print(double tsc_to_core, long tokens) {
#ifndef FX2_PROF
  (void)tsc_to_core;
  (void)tokens;
  std::printf("prof: not compiled in (build with -DFX2_PROF)\n");
#else
  // empty-section overhead: median back-to-back raw-rdtsc delta
  const int NS = 4001;
  std::vector<uint64_t> st(NS);
  for (int i = 0; i < NS; i++) st[i] = prof_rdtsc();
  std::vector<double> dd(NS - 1);
  for (int i = 0; i + 1 < NS; i++) dd[i] = double(st[i + 1] - st[i]);
  std::nth_element(dd.begin(), dd.begin() + (NS - 1) / 2, dd.end());
  const double stamp_ticks = dd[(NS - 1) / 2];
  std::printf("\n== per-part profile (raw rdtsc, overhead-corrected by %.1f "
              "ticks/section = %.1f core cyc) ==\n",
              stamp_ticks, stamp_ticks * tsc_to_core);
  double gcyc[4] = {}, gcalls[4] = {};
  double site_cyc[PS_N];
  double total = 0;
  for (int s = 0; s < PS_N; s++) {
    double ticks = double(g_pacc[s]) - double(g_pcalls[s]) * stamp_ticks;
    if (ticks < 0) ticks = 0;
    site_cyc[s] = ticks * tsc_to_core / double(tokens > 0 ? tokens : 1);
    gcyc[kPSites[s].group] += site_cyc[s];
    gcalls[kPSites[s].group] += double(g_pcalls[s]);
    total += site_cyc[s];
  }
  std::printf("%-34s %12s %6s %9s\n", "group", "cyc/token", "%", "calls/tok");
  for (int g = 0; g < 4; g++)
    std::printf("%-34s %12.0f %5.1f%% %9.1f\n", kGroups[g], gcyc[g],
                100.0 * gcyc[g] / total,
                gcalls[g] / double(tokens > 0 ? tokens : 1));
  std::printf("%-34s %12.0f %5.1f%%\n", "TOTAL (instrumented sections)", total,
              100.0);
  std::printf("\n%-34s %12s %6s %9s\n", "  site", "cyc/token", "%",
              "calls/tok");
  for (int g = 0; g < 4; g++) {
    std::printf("  -- %s --\n", kGroups[g]);
    for (int s = 0; s < PS_N; s++) {
      if (kPSites[s].group != g) continue;
      std::printf("  %-32s %12.0f %5.1f%% %9.1f\n", kPSites[s].name,
                  site_cyc[s], 100.0 * site_cyc[s] / total,
                  double(g_pcalls[s]) / double(tokens > 0 ? tokens : 1));
    }
  }
#endif
}

// ---------------------------------------------------------------------------
// the model
// ---------------------------------------------------------------------------
struct TransformerOptImpl {
  OptModel M;
  AttnKind kind;

  // streaming state (hugepage pool: KDA states, then KV caches)
  HugeBuf spool;
  KdaState* kst = nullptr;   // [arch::NK]
  uint8_t* kvp[arch::NV] = {};  // per-layer KV blobs (AttnKVF32T<W_vi> iff kind == KVF32, else AttnKVT<W_vi>; attn.h)
  int64_t t = 0;
  int64_t rope_off = 0;

#ifdef FX2_XCHECK_NAIVE_KDA
  struct NaiveKst {
    alignas(64) float S[NH][DH * DH];
    alignas(64) float hist[3][3][D];
  };
  std::vector<NaiveKst> nkst = std::vector<NaiveKst>(arch::NK);
#endif
#ifdef FX2_XCHECK_NAIVE_ATTN
  struct NaiveVst {
    alignas(64) int8_t kring[WMAX][D];  // rows [0, win(vi)) used
    alignas(64) int8_t vring[WMAX][D];
  };
  std::vector<NaiveVst> nvst = std::vector<NaiveVst>(arch::NV);
#endif

  // per-token skip stack (written by layers 0..5, read by 6..11 of the SAME
  // token) — transient within step
  alignas(64) float skip_store[NSKIP][D] = {};

  // scratch
  alignas(64) float x[D] = {}, xn[D] = {}, yb[D] = {};
  alignas(64) uint8_t q5[5 * D] = {};  // up to 5 biased-u8 copies of xn
  alignas(64) uint8_t q64b[DH] = {};
  alignas(64) float bq[D] = {}, bk[D] = {}, bv[D] = {};
  alignas(64) float graw[D] = {}, og192[D] = {}, gn[D] = {};
  alignas(32) float braw[8] = {};
  alignas(64) float qf[D] = {}, kf[D] = {}, vf[D] = {}, pre[D] = {};
  alignas(64) int8_t qq[D] = {}, kk[D] = {}, vv[D] = {};
  alignas(64) uint8_t q768[DMLP] = {};
  alignas(64) uint16_t idx768[DMLP + 16] = {};
  alignas(64) float prior_f32[208] = {};
  alignas(64) uint8_t q8p[224] = {};      // 224 = 205 rounded to 32
  alignas(64) uint16_t idxp[224 + 16] = {};
  alignas(64) float logits[208] = {};
  alignas(64) float probs208[208] = {};
  alignas(32) float sfall[32] = {}, cfall[32] = {};  // rope fallback row

  explicit TransformerOptImpl(const char* path, AttnKind k) : kind(k) {
    M.load(path);
    const size_t kda_sz = sizeof(KdaState) * arch::NK;
    size_t kv_sz = 0;  // per-layer KV blobs (sizes are multiples of 64: alignas(64) structs)
    for (int vi = 0; vi < arch::NV; vi++) kv_sz += attn_layer_kv_bytes(kind == AttnKind::KVF32, vi);
    spool.alloc(kda_sz + kv_sz);
    kst = reinterpret_cast<KdaState*>(spool.p);
    size_t off = kda_sz;
    for (int vi = 0; vi < arch::NV; vi++) {
      kvp[vi] = spool.p + off;
      off += attn_layer_kv_bytes(kind == AttnKind::KVF32, vi);
    }
    for (int i = 0; i < arch::NK; i++) kda_layer_reset(kst[i]);
  }

  void begin(int64_t rope_position_offset) {
    for (int i = 0; i < arch::NK; i++) kda_layer_reset(kst[i]);
#ifdef FX2_XCHECK_NAIVE_KDA
    std::memset(nkst.data(), 0, sizeof(NaiveKst) * arch::NK);
#endif
    t = 0;  // invalidates the KV rings (validity is [0, t] within an article)
    rope_off = rope_position_offset;
  }

  // ---- matmul kernel dispatch (qmat.h TF_AVX512, 2026-09-19) ----
  // On an AVX-512 host (M.avx512, decided once at load from cpuid; FX2_FORCE_AVX2=1 overrides) the 192-in dense
  // sites hold packed int4 + LUT arenas (QSite::pm, qmat.h section 4) consumed by the qmat_avx512.h vpdpbusd
  // kernels; the 64-in gate-down sites keep their unpacked QDense arena and use the AVX-512 QDense kernel; the
  // QSparse4 column arenas and the QW8 tables are shared by both paths. In an AVX2-only build (TF_AVX512=0) or
  // on an AVX2 host every helper is exactly the qmat_dense.h / qmat_sparse.h call it replaces. The two paths are
  // bit-identical (test_avx512 per kernel; test_e2e_opt with FX2_FORCE_AVX2=0/1 per model), so an archive
  // compressed on one decodes on the other. One perfectly predicted branch per matmul (~110 per token).
  inline void mm_f32(const QSite& s, const uint8_t* act, float* out) {
#if TF_AVX512
    if (M.avx512) {
      if (s.pm.arena) avx512::qgemv_pcb_f32(s.pm, act, out);
      else avx512::qgemv_f32(s.m, act, out);   // 192x64 gate-down (unpacked arena)
      return;
    }
#endif
    qgemv_f32(s.m, act, out);
  }
  inline void mm_f32s(const QSite& s, const uint8_t* act, float sc, float* out) {
#if TF_AVX512
    if (M.avx512) {
      if (s.pm.arena) avx512::qgemv_pcb_f32s(s.pm, act, sc, out);
      else avx512::qgemv_f32s(s.m, act, sc, out);   // 192x64 gate-down (unpacked arena)
      return;
    }
#endif
    qgemv_f32s(s.m, act, sc, out);
  }
  // the remaining epilogues run on 192-in sites only (pm is built for every one of them on an AVX-512 host)
  inline void mm_add(const QSite& s, const uint8_t* act, float* out) {
#if TF_AVX512
    if (M.avx512) { avx512::qgemv_pcb_add(s.pm, act, out); return; }
#endif
    qgemv_add(s.m, act, out);
  }
  inline void mm_adds(const QSite& s, const uint8_t* act, float sc, float* out) {
#if TF_AVX512
    if (M.avx512) { avx512::qgemv_pcb_adds(s.pm, act, sc, out); return; }
#endif
    qgemv_adds(s.m, act, sc, out);
  }
  inline int mm_relu2q(const QSite& s, const uint8_t* act, float s_next, uint8_t* q_out, uint16_t* idx_out) {
#if TF_AVX512
    if (M.avx512) return avx512::qgemv_pcb_relu2q(s.pm, act, s_next, q_out, idx_out);
#endif
    return qgemv_relu2q(s.m, act, s_next, q_out, idx_out);
  }
  inline void mm_quant_bias(const QSite& s, const uint8_t* act, float s_next, uint8_t* q_out) {
#if TF_AVX512
    if (M.avx512) { avx512::qgemv_pcb_quant_bias(s.pm, act, s_next, q_out); return; }
#endif
    qgemv_quant_bias(s.m, act, s_next, q_out);
  }
  inline int mm_relu2q_dyn(const QSite& s, const uint8_t* act, float s_in, uint8_t* q_out, uint16_t* idx_out,
                           float* s_next) {
#if TF_AVX512
    if (M.avx512) return avx512::qgemv_pcb_relu2q_dyn(s.pm, act, s_in, q_out, idx_out, s_next);
#endif
    return qgemv_relu2q_dyn(s.m, act, s_in, q_out, idx_out, s_next);
  }
  inline float mm_quant_bias_dyn(const QSite& s, const uint8_t* act, float s_in, uint8_t* q_out) {
#if TF_AVX512
    if (M.avx512) return avx512::qgemv_pcb_quant_bias_dyn(s.pm, act, s_in, q_out);
#endif
    return qgemv_quant_bias_dyn(s.m, act, s_in, q_out);
  }
  inline void mm_qw8(const QW8& m, const uint8_t* act, float* out) {
#if TF_AVX512
    if (M.avx512) { avx512::qw8_f32(m, act, out); return; }
#endif
    qw8_f32(m, act, out);
  }
  inline void sp4_add(const QSparse4& m, const uint8_t* q8, const uint16_t* idx, int nnz, float* out) {
#if TF_AVX512
    if (M.avx512) { avx512::qsparse4_add(m, q8, idx, nnz, out); return; }
#endif
    qsparse4_add(m, q8, idx, nnz, out);
  }
  inline void sp4_adds(const QSparse4& m, const uint8_t* q8, const uint16_t* idx, int nnz, float sc, float* out) {
#if TF_AVX512
    if (M.avx512) { avx512::qsparse4_adds(m, q8, idx, nnz, sc, out); return; }
#endif
    qsparse4_adds(m, q8, idx, nnz, sc, out);
  }
  inline void sp4_dense_add(const QSparse4& m, const uint8_t* q8, float* out) {
#if TF_AVX512
    if (M.avx512) { avx512::qsparse4_dense_add(m, q8, out); return; }
#endif
    qsparse4_dense_add(m, q8, out);
  }
  inline void sp4_dense_adds(const QSparse4& m, const uint8_t* q8, float sc, float* out) {
#if TF_AVX512
    if (M.avx512) { avx512::qsparse4_dense_adds(m, q8, sc, out); return; }
#endif
    qsparse4_dense_adds(m, q8, sc, out);
  }
  inline void sp4_f32(const QSparse4& m, const uint8_t* q8, const uint16_t* idx, int nnz, float* out) {
#if TF_AVX512
    if (M.avx512) { avx512::qsparse4_f32(m, q8, idx, nnz, out); return; }
#endif
    qsparse4_f32(m, q8, idx, nnz, out);
  }
  inline void sp4_f32s(const QSparse4& m, const uint8_t* q8, const uint16_t* idx, int nnz, float sc, float* out) {
#if TF_AVX512
    if (M.avx512) { avx512::qsparse4_f32s(m, q8, idx, nnz, sc, out); return; }
#endif
    qsparse4_f32s(m, q8, idx, nnz, sc, out);
  }
  inline void sp4_dense_f32(const QSparse4& m, const uint8_t* q8, float* out) {
#if TF_AVX512
    if (M.avx512) { avx512::qsparse4_dense_f32(m, q8, out); return; }
#endif
    qsparse4_dense_f32(m, q8, out);
  }
  inline void sp4_dense_f32s(const QSparse4& m, const uint8_t* q8, float sc, float* out) {
#if TF_AVX512
    if (M.avx512) { avx512::qsparse4_dense_f32s(m, q8, sc, out); return; }
#endif
    qsparse4_dense_f32s(m, q8, sc, out);
  }

  void kimi_layer(int ki) {
    KimiArenas& L = M.kimi[ki];
#if TF_ACTQ_DYN
    // dynamic per-token activation scales (tf_arch.h): ONE quantized copy of xn (its own amax scale) feeds all five
    // projections; every matmul output is scaled by its input's token scale inside the kernel epilogue; the 64-dim
    // gate intermediates get their own dynamic scale (qgemv_quant_bias_dyn)
    float s_in;
    {
      PSCOPE(PS_EL_NQ_KIMI);
      s_in = rms_norm_quant192_dyn(x, xn, q5);
    }
    {
      PSCOPE(PS_MM_KQKV);
      mm_f32s(L.qp, q5, s_in, bq);
      mm_f32s(L.kp, q5, s_in, bk);
      mm_f32s(L.vp, q5, s_in, bv);
    }
    float s64;
    {
      PSCOPE(PS_MM_GUP);
      s64 = mm_quant_bias_dyn(L.fg_up, q5, s_in, q64b);
    }
    {
      PSCOPE(PS_MM_GDN);
      mm_f32s(L.fg_down, q64b, s64, graw);
    }
    {
      PSCOPE(PS_MM_GUP);
      s64 = mm_quant_bias_dyn(L.og_up, q5, s_in, q64b);
    }
    {
      PSCOPE(PS_MM_GDN);
      mm_f32s(L.og_down, q64b, s64, og192);
    }
#else
    {
      PSCOPE(PS_EL_NQ_KIMI);
      const float s5[5] = {L.qp.s_act, L.kp.s_act, L.vp.s_act, L.fg_up.s_act,
                           L.og_up.s_act};
      rms_norm_quant192_multi(x, xn, s5, 5, q5);
    }
    {
      PSCOPE(PS_MM_KQKV);
      mm_f32(L.qp, q5, bq);
      mm_f32(L.kp, q5 + D, bk);
      mm_f32(L.vp, q5 + 2 * D, bv);
    }
    {
      PSCOPE(PS_MM_GUP);
      mm_quant_bias(L.fg_up, q5 + 3 * D, L.fg_down.s_act, q64b);
    }
    {
      PSCOPE(PS_MM_GDN);
      mm_f32(L.fg_down, q64b, graw);
    }
    {
      PSCOPE(PS_MM_GUP);
      mm_quant_bias(L.og_up, q5 + 4 * D, L.og_down.s_act, q64b);
    }
    {
      PSCOPE(PS_MM_GDN);
      mm_f32(L.og_down, q64b, og192);
    }
#endif
    {
      PSCOPE(PS_KD_BETA);
      for (int h = 0; h < NH; h++)
        braw[h] = dot192(xn, L.beta_w + size_t(h) * D);
    }
    {
      PSCOPE(PS_KD_STEP);
#ifdef FX2_XCHECK_NAIVE_KDA
      // naive scalar kimi path (bit-exact vs src/model.cpp kimi_attention)
      NaiveKst& st = nkst[ki];
      alignas(32) float cq[D], ck[D], cv[D], o192[D];
      conv4_silu(L.kw.conv_w[0], st.hist[0][0], st.hist[0][1], st.hist[0][2],
                 bq, cq, D);
      conv4_silu(L.kw.conv_w[1], st.hist[1][0], st.hist[1][1], st.hist[1][2],
                 bk, ck, D);
      conv4_silu(L.kw.conv_w[2], st.hist[2][0], st.hist[2][1], st.hist[2][2],
                 bv, cv, D);
      const float* newest[3] = {bq, bk, bv};
      for (int c = 0; c < 3; c++) {
        std::memmove(st.hist[c][0], st.hist[c][1], sizeof(float) * 2 * D);
        std::memcpy(st.hist[c][2], newest[c], sizeof(float) * D);
      }
      for (int h = 0; h < NH; h++)
        kda_head_step(st.S[h], cq + h * DH, ck + h * DH, cv + h * DH,
                      graw + h * DH, L.kw.dt_bias + h * DH, L.kw.a_neg[h],
                      sigmoid1f(braw[h]), o192 + h * DH);
      for (int h = 0; h < NH; h++)
        gated_rms_norm64(o192 + h * DH, og192 + h * DH, L.kw.gn_w,
                         gn + h * DH);
#else
      kda_layer_step(L.kw, kst[ki], bq, bk, bv, graw, og192, braw, gn);
#endif
    }
#if TF_ACTQ_DYN
    float s_o;
    {
      PSCOPE(PS_EL_OQ);
      s_o = quant192_u8_dyn(gn, q5);
    }
    {
      PSCOPE(PS_MM_KOP);
      mm_adds(L.op, q5, s_o, x);
    }
#else
    {
      PSCOPE(PS_EL_OQ);
      quant192_u8(gn, L.op.s_act, q5);
    }
    {
      PSCOPE(PS_MM_KOP);
      mm_add(L.op, q5, x);
    }
#endif
  }

  void van_layer(int vi) {
    VanArenas& L = M.van[vi];
#if TF_ACTQ_DYN
    float s_in;
    {
      PSCOPE(PS_EL_NQ_VAN);
      s_in = rms_norm_quant192_dyn(x, xn, q5);  // one dynamically quantized copy for q/k/v
    }
    {
      PSCOPE(PS_MM_VQKV);
      mm_f32s(L.qp, q5, s_in, qf);
      mm_f32s(L.kp, q5, s_in, kf);
      mm_f32s(L.vp, q5, s_in, vf);
    }
#else
    {
      PSCOPE(PS_EL_NQ_VAN);
      const float s3[3] = {L.qp.s_act, L.kp.s_act, L.vp.s_act};
      rms_norm_quant192_x3(x, xn, s3, q5, q5 + D, q5 + 2 * D);
    }
    {
      PSCOPE(PS_MM_VQKV);
      mm_f32(L.qp, q5, qf);
      mm_f32(L.kp, q5 + D, kf);
      mm_f32(L.vp, q5 + 2 * D, vf);
    }
#endif
    {
      PSCOPE(PS_EL_HEADPREP);
      for (int h = 0; h < NH; h++) rms_norm64(qf + h * DH, qf + h * DH);
      for (int h = 0; h < NH; h++) rms_norm64(kf + h * DH, kf + h * DH);
      const int64_t pos = rope_off + t;
      const float *sp, *cp;
      if (pos < ROPE_LEN) {
        sp = M.rope_sin.data() + size_t(pos) * 32;
        cp = M.rope_cos.data() + size_t(pos) * 32;
      } else {  // beyond the shipped table: libm fallback (same as naive)
        const float fpos = static_cast<float>(pos);
        for (int i = 0; i < 32; i++) {
          const float ang = fpos * M.inv_freq[i];
          sfall[i] = std::sin(ang);
          cfall[i] = std::cos(ang);
        }
        sp = sfall;
        cp = cfall;
      }
      rope_apply_192(qf, sp, cp);
      rope_apply_192(kf, sp, cp);
      for (int h = 0; h < NH; h++) {
        quant64_i8(qf + h * DH, L.sq[h], qq + h * DH);
        quant64_i8(kf + h * DH, L.sk[h], kk + h * DH);
        quant64_i8(vf + h * DH, L.sv[h], vv + h * DH);
      }
    }
#ifdef FX2_EXP_KPF
    {  // experiment: warm the first 2KB of each head's K stream (the scan's
       // software prefetch runs +2KB ahead, so the first 2KB are cold-start
       // demand misses paced by the QK compute)
      const char* kb = reinterpret_cast<const char*>(kvp[vi]);  // K is the first member of both KV types
      const int win_vi = attn_win::win(vi);
      for (int h = 0; h < 3; h++)
        for (int off = 0; off < 2048; off += 64)
          _mm_prefetch(kb + h * ((win_vi / ATTN_BLK) * 32 * ATTN_DH) + off, _MM_HINT_T0);
    }
#endif
#ifdef FX2_XCHECK_NAIVE_ATTN
    {
      NaiveVst& st = nvst[vi];
      const int win_vi = attn_win::win(vi);
      const int slot = static_cast<int>(t % win_vi);
      const int64_t n = t + 1;
      std::memcpy(st.kring[slot], kk, D);
      std::memcpy(st.vring[slot], vv, D);
      if (n < win_vi)
        fx2::attention_step_var(qq, st.kring[0], st.vring[0], L.coef, L.sv,
                                static_cast<int>(n), pre, 0.0f);
      else
        fx2::attention_step_fixed(qq, st.kring[0], st.vring[0], L.coef, L.sv,
                                  pre, 0.0f, win_vi);
    }
#else
    // per-layer window (attn.h attn_layer_*): ring slot t % W_vi, var kernel while t + 1 < W_vi, fixed kernel after
    {
      PSCOPE(PS_AT_INSERT);
      attn_layer_insert(kind == AttnKind::KVF32, vi, kvp[vi], t, kk, vv);
    }
    {
      PSCOPE(PS_AT_STEP);
      attn_layer_step(kind == AttnKind::KVF32, vi, kvp[vi], qq, L.coef, L.sv, t, pre, 0.0f);
    }
#endif
#if TF_ACTQ_DYN
    float s_o;
    {
      PSCOPE(PS_EL_OQ);
      s_o = quant192_u8_dyn(pre, q5);
    }
    {
      PSCOPE(PS_MM_VOP);
      mm_adds(L.op, q5, s_o, x);
    }
#else
    {
      PSCOPE(PS_EL_OQ);
      quant192_u8(pre, L.op.s_act, q5);
    }
    {
      PSCOPE(PS_MM_VOP);
      mm_add(L.op, q5, x);
    }
#endif
  }

  void mlp_block(int l) {
    MlpArenas& mm = M.mlp[l];
#if TF_ACTQ_DYN
    float s_in;
    {
      PSCOPE(PS_EL_NQ_MLP);
      s_in = rms_norm_quant192_dyn(x, xn, q5);
    }
    int nnz;
    float s_h;  // dynamic scale of the relu^2 vector (an all-zero vector: s_h = 1e-12/127, q = 0, nnz = 0)
    {
      PSCOPE(PS_MM_MLP_UP);
      nnz = mm_relu2q_dyn(mm.up, q5, s_in, q768, idx768, &s_h);
    }
    {
      PSCOPE(PS_MM_MLP_DOWN);
      if (nnz > DOWN_DENSE_NNZ)
        sp4_dense_adds(mm.down, q768, s_h, x);
      else
        sp4_adds(mm.down, q768, idx768, nnz, s_h, x);
    }
#else
    {
      PSCOPE(PS_EL_NQ_MLP);
      rms_norm_quant192(x, xn, mm.up.s_act, q5);
    }
    int nnz;
    {
      PSCOPE(PS_MM_MLP_UP);
      nnz = mm_relu2q(mm.up, q5, mm.down_s_act, q768, idx768);
    }
    {
      PSCOPE(PS_MM_MLP_DOWN);
      if (nnz > DOWN_DENSE_NNZ)
        sp4_dense_add(mm.down, q768, x);
      else
        sp4_add(mm.down, q768, idx768, nnz, x);
    }
#endif
  }

  // prior must be the cap-208 internal buffer with pads [205..208) zeroed
  void step(uint8_t token, float* probs_out) {
    const float* tok = M.tok_table + size_t(token) * D;
    int nnzp;
#if TF_ACTQ_DYN
    float s_p;
#endif
    {
      PSCOPE(PS_EL_PRIORQ);
#if TF_ACTQ_DYN
      s_p = prior_quant_raw_dyn(prior_f32, q8p);   // raw u8 with the row's own scale; q8p[208..224)=0
#else
      prior_quant_raw(prior_f32, M.prior_s_act, q8p);  // raw u8; q8p[208..224)=0
#endif
      nnzp = qsparse_make_idx(q8p, V, idxp);
      const uint16_t fillv = nnzp ? idxp[nnzp - 1] : 0;
      for (int k = nnzp; k < nnzp + 8; k++) idxp[k] = fillv;
    }
    {
      PSCOPE(PS_MM_PRIOR);
#if QMAT_SMALL_W8
      (void)nnzp;
      mm_qw8(M.prior8, q8p, yb);   // 8-bit prior projection (qmat.h); q8p zero-padded to 224
#if TF_ACTQ_DYN
      scale_vec_n(yb, D, s_p);      // (fold*dot)*s_p, separately rounded (= naive qmatvec -> scale_vec)
#endif
#elif TF_ACTQ_DYN
      if (nnzp > PRIOR_DENSE_NNZ)
        sp4_dense_f32s(M.prior, q8p, s_p, yb);
      else
        sp4_f32s(M.prior, q8p, idxp, nnzp, s_p, yb);
#else
      if (nnzp > PRIOR_DENSE_NNZ)
        sp4_dense_f32(M.prior, q8p, yb);
      else
        sp4_f32(M.prior, q8p, idxp, nnzp, yb);
#endif
    }
    {
      PSCOPE(PS_EL_EMBED);
      embed_combine192(tok, yb, x);  // x0 = tok_row + rms_norm(prior_y)
    }

    for (int l = 0; l < NL; l++) {
      {
        PSCOPE(PS_EL_RESID);
        // skip-add BEFORE the token connection (SPEC 3.3); pairing 11-l
        if (l >= NL - NSKIP) add_scaled192(x, M.skip_w[l - (NL - NSKIP)], skip_store[NL - 1 - l]);
        axpby_tok192(M.rsc[l], x, M.tec[l], tok);
      }
      if (OptModel::KIMI_L(l))
        kimi_layer(M.layer2kimi[l]);
      else
        van_layer(M.layer2van[l]);
      mlp_block(l);
      if (l < NSKIP) {
        PSCOPE(PS_EL_RESID);
        std::memcpy(skip_store[l], x, sizeof(float) * D);  // push AFTER block
      }
    }

#if TF_ACTQ_DYN
    float s_f;
    {
      PSCOPE(PS_EL_NQ_FIN);
      s_f = rms_norm_quant192_dyn(x, xn, q5);
    }
    {
      PSCOPE(PS_MM_UNEMB);
#if QMAT_SMALL_W8
      mm_qw8(M.unembed8, q5, logits);  // 8-bit unembedding, rows_padded 208
      scale_vec_n(logits, 208, s_f);   // pad rows stay 0
#else
      mm_f32s(M.unembed, q5, s_f, logits);  // rows_padded 208
#endif
    }
#else
    {
      PSCOPE(PS_EL_NQ_FIN);
      rms_norm_quant192(x, xn, M.unembed.s_act, q5);
    }
    {
      PSCOPE(PS_MM_UNEMB);
#if QMAT_SMALL_W8
      mm_qw8(M.unembed8, q5, logits);  // 8-bit unembedding, rows_padded 208
#else
      mm_f32(M.unembed, q5, logits);  // rows_padded 208
#endif
    }
#endif
    {
      PSCOPE(PS_EL_HEAD);
      head_softcap_softmax(logits, probs208);
      std::memcpy(probs_out, probs208, sizeof(float) * V);
    }
    t++;
  }
};

TransformerOpt::TransformerOpt(const char* weights_path, AttnKind attn)
    : impl(new TransformerOptImpl(weights_path, attn)) {}

TransformerOpt::~TransformerOpt() = default;

void TransformerOpt::begin_article(int64_t rope_position_offset) {
  impl->begin(rope_position_offset);
}

void TransformerOpt::step(uint8_t token, const uint16_t* prior_f16,
                          float* probs_out) {
  prior_f16_to_f32(prior_f16, impl->prior_f32);  // exact; pads zeroed
  impl->step(token, probs_out);
}

void TransformerOpt::step(uint8_t token, const float* prior205,
                          float* probs_out) {
  std::memcpy(impl->prior_f32, prior205, sizeof(float) * V);
  impl->prior_f32[205] = impl->prior_f32[206] = impl->prior_f32[207] = 0.0f;
  impl->step(token, probs_out);
}

const float* TransformerOpt::last_logits() const { return impl->logits; }
const uint8_t* TransformerOpt::last_hidden_q8() const { return impl->q5; }

AttnKind TransformerOpt::attn_kind() const { return impl->kind; }

}  // namespace opt
}  // namespace fx2
